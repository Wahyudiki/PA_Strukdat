#include <iostream>
#include <string>
#include <iomanip>
#include <vector>
#include <limits>
#include <cmath>

using namespace std;

// Struktur data untuk menyimpan informasi rute
struct Rute {
    string asal;
    string tujuan;
    string jamKeberangkatan;
    string jamKedatangan;
    double harga;
};

// Struktur data untuk menyimpan informasi pengguna
struct Pengguna {
    string username;
    string password;
};

// Struktur data untuk menyimpan pemesanan tiket dengan informasi pengguna
struct Pemesanan {
    string username;
    string asal;
    string tujuan;
    double harga;
};

// Node untuk Linked List
struct NodeRute {
    Rute data;
    NodeRute* next;
};

// Node untuk Stack 
struct NodePemesanan {
    Pemesanan data;
    NodePemesanan* next;
};

// Node untuk Queue (Antrian)
struct NodePemesananQueue {
    Pemesanan data;
    NodePemesananQueue* next;
};

class SistemTiketKereta {
private:
    NodeRute* headRute; // Linked List untuk rute
    NodePemesanan* topPemesanan; // Stack untuk pemesanan
    NodePemesananQueue* frontQueue; // Front Queue untuk antrian pemesanan
    NodePemesananQueue* rearQueue;  // Rear Queue untuk antrian pemesanan
    vector<Pengguna> penggunaList; // Daftar pengguna


    // Fungsi untuk login pengguna
    bool loginPengguna(string username, string password) {
        for (auto& pengguna : penggunaList) {
            if (pengguna.username == username && pengguna.password == password) {
                return true;
            }
        }
        return false;
    }

    // Fungsi untuk login admin
    bool loginAdmin(string username, string password) {
        return username == "admin" && password == "admin123";
    }

    // Fungsi untuk menambah rute oleh admin
    void tambahRute() {
        Rute rute;
        cout << "Masukkan asal rute: ";
        cin >> rute.asal;
        cout << "Masukkan tujuan rute: ";
        cin >> rute.tujuan;
        cout << "Masukkan jam keberangkatan: ";
        cin >> rute.jamKeberangkatan;
        cout << "Masukkan jam kedatangan: ";
        cin >> rute.jamKedatangan;
        cout << "Masukkan harga tiket: ";
        cin >> rute.harga;
        

        NodeRute* newNode = new NodeRute{rute, nullptr};
        if (!headRute) {
            headRute = newNode;
        } else {
            NodeRute* temp = headRute;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
        cout << "Rute berhasil ditambahkan!" << endl;
    }

    // Fungsi untuk melihat semua rute dalam format tabel
    void lihatRute() {
        if (!headRute) {
            cout << "Tidak ada rute yang tersedia." << endl;
            return;
        }

        // Menampilkan header tabel
        cout << "\nNo | Asal - Tujuan                   | Keberangkatan | Kedatangan   | Harga       \n";
        cout << "---------------------------------------------------------------------------------------------------\n";

        // Menampilkan setiap rute dengan nomor urut
        NodeRute* temp = headRute;
        int no = 1;
        while (temp) {
            cout << left
                 << setw(3)  << no++
                 << " | "
                 << setw(30) << temp->data.asal + " ke " + temp->data.tujuan
                 << " | "
                 << setw(13) << temp->data.jamKeberangkatan
                 << " | "
                 << setw(12) << temp->data.jamKedatangan
                 << " | "
                 << "Rp " << setw(10) << fixed << setprecision(2) << temp->data.harga
                 << endl;
            temp = temp->next;
        }
    }

    // Fungsi untuk pemesanan tiket menggunakan Stack
    void pesanTiket(string username) {
        string asal, tujuan;
        cout << "Masukkan asal tujuan yang ingin dipesan (contoh: Jakarta Bandung): ";
        cin >> asal >> tujuan;

        NodeRute* temp = headRute;
        bool found = false;
        while (temp) {
            if (temp->data.asal == asal && temp->data.tujuan == tujuan) {
                Pemesanan pemesanan;
                pemesanan.username = username;
                pemesanan.asal = asal;
                pemesanan.tujuan = tujuan;
                pemesanan.harga = temp->data.harga;

                // Menambah pemesanan ke Stack
                NodePemesanan* newNode = new NodePemesanan{pemesanan, topPemesanan};
                topPemesanan = newNode;

                cout << "Tiket berhasil dipesan dari " << asal << " ke " << tujuan << " dengan harga Rp " 
                     << fixed << setprecision(2) << temp->data.harga << endl;
                found = true;
                break;
            }
            temp = temp->next;
        }
        if (!found) {
            cout << "Rute tidak ditemukan!" << endl;
        }
    }




    // Fungsi untuk registrasi pengguna baru
    void registrasi() {
        string username, password;
        cout << "Masukkan username baru: ";
        cin >> username;
        cout << "Masukkan password baru: ";
        cin >> password;

        // Memastikan username belum terdaftar
        for (const auto& pengguna : penggunaList) {
            if (pengguna.username == username) {
                cout << "Username sudah terdaftar!" << endl;
                return;
            }
        }

        // Menambah pengguna baru
        Pengguna penggunaBaru = {username, password};
        penggunaList.push_back(penggunaBaru);
        cout << "Registrasi berhasil! Anda dapat login sekarang." << endl;
    }
    

// Fungsi untuk mengedit rute berdasarkan nomor urut
void editRute() {
    if (!headRute) {
        cout << "Tidak ada rute yang dapat diedit." << endl;
        return;
    }

    lihatRute();  // Menampilkan semua rute terlebih dahulu

    int no;
    cout << "Masukkan nomor rute yang ingin diedit: ";
    cin >> no;

    if (no <= 0) {
        cout << "Nomor rute tidak valid!" << endl;
        return;
    }

    NodeRute* temp = headRute;
    int count = 1;

    // Mencari rute yang sesuai dengan nomor yang dimasukkan
    while (temp && count < no) {
        temp = temp->next;
        count++;
    }

    if (!temp) {
        cout << "Rute tidak ditemukan!" << endl;
        return;
    }

    // Mengedit rute yang ditemukan
    cout << "Edit rute dari " << temp->data.asal << " ke " << temp->data.tujuan << endl;

    cout << "Masukkan asal rute baru: ";
    cin >> temp->data.asal;
    cout << "Masukkan tujuan rute baru: ";
    cin >> temp->data.tujuan;
    cout << "Masukkan jam keberangkatan baru: ";
    cin >> temp->data.jamKeberangkatan;
    cout << "Masukkan jam kedatangan baru: ";
    cin >> temp->data.jamKedatangan;
    cout << "Masukkan harga tiket baru: ";
    cin >> temp->data.harga;
    cout << "Rute berhasil diedit!" << endl;
     while (true) {
        try {
            cout << "Masukkan nomor rute yang ingin diedit: ";
            
            // Gunakan stringstream untuk memisahkan angka dan huruf secara otomatis
            string str;
            getline(cin, str);

            size_t pos = str.find_first_not_of(' ');
            if (pos == string::npos) throw runtime_error("");

            no = stoi(str.substr(pos));

            if (no <= 0) {
                cerr << "Nomor rute tidak boleh nol atau negatif.\n";
                continue;
            }

            break;
        } catch (...) {
            cerr << "Input tidak valid Silakan masukkan lagi.\n";
        }
    }
}
  
// Fungsi untuk menambah pemesanan ke Queue
    void belitiket(string username) {
    if (!headRute) {
        cout << "Tidak ada rute yang tersedia." << endl;
        return;
    }

    // Tampilkan daftar rute seperti di fungsi lihatRute
    cout << "\nDaftar Rute Tersedia:\n";
    cout << left << setw(5) << "No" << setw(15) << "Asal"
         << setw(15) << "Tujuan" << setw(15) << "Keberangkatan"
         << setw(15) << "Kedatangan" << setw(10) << "Harga" << endl;
    cout << string(70, '-') << endl;

    NodeRute* temp = headRute;
    int no = 1;
    while (temp) {
        cout << left << setw(5) << no++
             << setw(15) << temp->data.asal
             << setw(15) << temp->data.tujuan
             << setw(15) << temp->data.jamKeberangkatan
             << setw(15) << temp->data.jamKedatangan
             << "Rp " << setw(10) << fixed << setprecision(2) << temp->data.harga
             << endl;
        temp = temp->next;
    }

    // Meminta input nomor rute dari user
    int pilihanRute;
    cout << "\nMasukkan nomor rute yang ingin dipesan: ";
    while (true) {
        cin >> pilihanRute;

        // Validasi input
        if (cin.fail() || pilihanRute < 1 || pilihanRute >= no) {
            cout << "Input tidak valid! Masukkan nomor rute yang sesuai: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        } else {
            break;
        }
    }

    // Cari rute berdasarkan nomor
    temp = headRute;
    no = 1;
    while (temp && no < pilihanRute) {
        temp = temp->next;
        no++;
    }

    if (!temp) {
        cout << "Rute tidak ditemukan!" << endl;
        return;
    }

    // Menambahkan pemesanan ke dalam antrean
    NodePemesananQueue* newPemesanan = new NodePemesananQueue{
        {username, temp->data.asal, temp->data.tujuan, temp->data.harga},
        nullptr
    };

    if (!rearQueue) {
        frontQueue = rearQueue = newPemesanan;
    } else {
        rearQueue->next = newPemesanan;
        rearQueue = newPemesanan;
    }

    cout << "Tiket berhasil dipesan!\n";
    cout << "Detail Pemesanan:\n";
    cout << "Username: " << username << endl;
    cout << "Asal: " << temp->data.asal << endl;
    cout << "Tujuan: " << temp->data.tujuan << endl;
    cout << "Harga: Rp " << fixed << setprecision(2) << temp->data.harga << endl;
}


// Fungsi untuk membagi linked list menjadi dua bagian (untuk Merge Sort)
NodeRute* split(NodeRute* head) {
    NodeRute* fast = head->next;
    NodeRute* slow = head;

    while (fast != nullptr && fast->next != nullptr) {
        fast = fast->next->next;
        slow = slow->next;
    }
    NodeRute* temp = slow->next;
    slow->next = nullptr;
    return temp;
}


// Fungsi untuk menggabungkan dua linked list yang sudah terurut (untuk Merge Sort)
NodeRute* merge(NodeRute* left, NodeRute* right) {
    if (!left) return right;
    if (!right) return left;

    if (left->data.jamKeberangkatan <= right->data.jamKeberangkatan) {
        left->next = merge(left->next, right);
        return left;
    } else {
        right->next = merge(left, right->next);
        return right;
    }
}

// Fungsi utama Merge Sort
NodeRute* mergeSort(NodeRute* head) {
    if (!head || !head->next) return head;

    NodeRute* second = split(head);
    head = mergeSort(head);
    second = mergeSort(second);

    return merge(head, second);
}

// Fungsi untuk mengurutkan rute berdasarkan jam keberangkatan (Merge Sort)
void sortingJamKeberangkatan() {
    if (!headRute || !headRute->next) {
        cout << "Tidak ada rute atau hanya satu rute yang tersedia, tidak perlu sorting." << endl;
        return;
    }

    headRute = mergeSort(headRute);
    cout << "Rute berhasil diurutkan berdasarkan jam keberangkatan!" << endl;
    lihatRute();  // Tampilkan rute setelah disorting
}



// Fungsi untuk melakukan Shell Sort
void shellSort() {
    if (!headRute || !headRute->next) {
        cout << "Tidak ada rute atau hanya satu rute yang tersedia, tidak perlu sorting." << endl;
        return;
    }

    // Menemukan jumlah elemen dalam list
    int n = 0;
    NodeRute* temp = headRute;
    while (temp != nullptr) {
        n++;
        temp = temp->next;
    }

    // Mulai dengan gap besar
    for (int gap = n / 2; gap > 0; gap /= 2) {
        // Melakukan perulangan untuk setiap gap
        for (int i = gap; i < n; i++) {
            // Menemukan node ke-i
            NodeRute* current = headRute;
            for (int j = 0; j < i; j++) {
                current = current->next;  
            }

            // Menyimpan nilai harga tiket yang akan dipindahkan
            double key = current->data.harga;
            NodeRute* prev = current;
            NodeRute* nextNode = current->next;

            // Cari tempat yang tepat untuk harga tiket
            while (nextNode != nullptr && nextNode->data.harga < key) {
                prev->data = nextNode->data;  // Pindahkan data dari nextNode ke prev
                prev = nextNode;  // Geser prev ke nextNode
                nextNode = nextNode->next;  // Geser nextNode ke node berikutnya
            }

            // Menempatkan data key ke posisi yang tepat
            prev->data.harga = key;  // Set harga ke key
        }
    }

    cout << "Rute berhasil diurutkan berdasarkan harga tiket dengan Shell Sort!" << endl;
    lihatRute();  // Tampilkan rute setelah disorting
}

    

    // Fungsi untuk melihat antrian pemesanan
    void liatantrian() {
        if (!frontQueue) {
            cout << "Tidak ada pemesanan yang antri." << endl;
            return;
        }

        cout << "\nDaftar Pemesanan Antri:\n";
        cout << left << setw(20) << "Username" << setw(20) << "Asal - Tujuan" << setw(15) << "Harga\n";
        cout << "-----------------------------------------------\n";

        NodePemesananQueue* temp = frontQueue;
        while (temp) {
            cout << left << setw(20) << temp->data.username
                 << setw(20) << temp->data.asal + " - " + temp->data.tujuan
                 << setw(15) << fixed << setprecision(2) << temp->data.harga << endl;
            temp = temp->next;
        }
    }

    // Fungsi untuk Fibonacci Search berdasarkan harga
    int fibonacciSearch(double harga) {
        vector<Rute> ruteList;
        NodeRute* temp = headRute;
        while (temp) {
            ruteList.push_back(temp->data);
            temp = temp->next;
        }

        int n = ruteList.size();
        int fibM2 = 0; // (m-2)'th Fibonacci number
        int fibM1 = 1; // (m-1)'th Fibonacci number
        int fibM = fibM1 + fibM2; // m'th Fibonacci number

        while (fibM < n) {
            fibM2 = fibM1;
            fibM1 = fibM;
            fibM = fibM1 + fibM2;
        }

        int offset = -1;

        while (fibM > 1) {
            int i = min(offset + fibM2, n - 1);

            if (ruteList[i].harga == harga) {
                cout << "Rute ditemukan dengan harga Rp " << harga << ":\n";
                cout << "Asal: " << ruteList[i].asal << ", Tujuan: " << ruteList[i].tujuan << endl;
                cout << "Jam Keberangkatan: " << ruteList[i].jamKeberangkatan << endl;
                cout << "Jam Kedatangan: " << ruteList[i].jamKedatangan << endl;
                return 1;
            } else if (ruteList[i].harga < harga) {
                fibM = fibM1;
                fibM1 = fibM2;
                fibM2 = fibM - fibM1;
                offset = i;
            } else {
                fibM = fibM2;
                fibM1 -= fibM2;
                fibM2 = fibM - fibM1;
            }
        }

        if (fibM1 && offset + 1 < n && ruteList[offset + 1].harga == harga) {
            cout << "Rute ditemukan dengan harga Rp " << harga << ":\n";
            cout << "Asal: " << ruteList[offset + 1].asal << ", Tujuan: " << ruteList[offset + 1].tujuan << endl;
            cout << "Jam Keberangkatan: " << ruteList[offset + 1].jamKeberangkatan << endl;
            cout << "Jam Kedatangan: " << ruteList[offset + 1].jamKedatangan << endl;
            return 1;
        }

        cout << "Rute tidak ditemukan dengan harga Rp " << harga << "!" << endl;
        return -1;
    }

// Fungsi untuk Jump Search berdasarkan jam keberangkatan
int jumpSearch(string jamKeberangkatan) {
    vector<Rute> ruteList;
    NodeRute* temp = headRute;
    while (temp) {
        ruteList.push_back(temp->data);
        temp = temp->next;
    }

    int n = ruteList.size();
    int jump = sqrt(n); 
    int prev = 0;

    // Melakukan pencarian dengan langkah
    while (prev < n && ruteList[min(jump, n) - 1].jamKeberangkatan < jamKeberangkatan) {
        prev = jump;
        jump += sqrt(n);
        if (prev >= n) {
            cout << "Rute tidak ditemukan dengan jam keberangkatan " << jamKeberangkatan << "!" << endl;
            return -1;
        }
    }

    // Melakukan pencarian linear di dalam blok yang ditemukan
    for (int i = prev; i < min(jump, n); i++) {
        if (ruteList[i].jamKeberangkatan == jamKeberangkatan) {
            cout << "Rute ditemukan dengan jam keberangkatan " << jamKeberangkatan << ":\n";
            cout << "Asal: " << ruteList[i].asal << ", Tujuan: " << ruteList[i].tujuan << endl;
            cout << "Harga: Rp " << fixed << setprecision(2) << ruteList[i].harga << endl;
            return 1;
        }
    }

    cout << "Rute tidak ditemukan dengan jam keberangkatan " << jamKeberangkatan << "!" << endl;
    return -1;
}

    // Fungsi untuk Boyer-Moore Search berdasarkan asal
    int boyerMooreSearch(string asal) {
        NodeRute* temp = headRute;
        while (temp) {
            if (temp->data.asal == asal) {
                cout << "Rute ditemukan dengan asal " << asal << ":\n";
                cout << "Tujuan: " << temp->data.tujuan << endl;
                cout << "Jam Keberangkatan: " << temp->data.jamKeberangkatan << endl;
                cout << "Jam Kedatangan: " << temp->data.jamKedatangan << endl;
                cout << "Harga: Rp " << fixed << setprecision(2) << temp->data.harga << endl;
                return 1;
            }
            temp = temp->next;
        }
        cout << "Rute tidak ditemukan dengan asal " << asal << "!" << endl;
        return -1;
    }

    // Fungsi untuk mencari rute dengan pilihan metode pencarian
    void cariRute() {
        string asal, tujuan;
        double harga;
        string jamKeberangkatan;
        int pilihan;

        cout << "Pilih metode pencarian:\n";
        cout << "1. Fibonacci Search (berdasarkan harga)\n";
        cout << "2. Jump Search (berdasarkan jam keberangkatan)\n";
        cout << "3. Boyer-Moore Search (berdasarkan asal)\n";
        cout << "Pilih opsi: ";
        cin >> pilihan;

        switch (pilihan) {
            case 1:
                cout << "Masukkan harga yang ingin dicari: ";
                cin >> harga;
                fibonacciSearch(harga);
                break;
            case 2:
                cout << "Masukkan jam keberangkatan yang ingin dicari: ";
                cin >> jamKeberangkatan;
                jumpSearch(jamKeberangkatan);
                break;
            case 3:
                cout << "Masukkan asal yang ingin dicari: ";
                cin >> asal;
                boyerMooreSearch(asal);
                break;
            default:
                cout << "Pilihan tidak valid!" << endl;
                break;
        }
    }

    // Fungsi untuk menghapus rute berdasarkan nomor urut
void hapusrute() {
    if (!headRute) {
        cout << "Tidak ada rute yang dapat dihapus." << endl;
        return;
    }

    lihatRute();  // Menampilkan semua rute terlebih dahulu

    int no;
    cout << "Masukkan nomor rute yang ingin dihapus: ";
    cin >> no;

    if (no <= 0) {
        cout << "Nomor rute tidak valid!" << endl;
        return;
    }

    NodeRute* temp = headRute;
    NodeRute* prev = nullptr;
    int count = 1;

    // Mencari rute yang sesuai dengan nomor yang dimasukkan
    while (temp && count < no) {
        prev = temp;
        temp = temp->next;
        count++;
    }

    

    if (!temp) {
        cout << "Rute tidak ditemukan!" << endl;
        return;
    }

    // Menghapus rute yang ditemukan
    if (prev) {
        prev->next = temp->next;  // Menghubungkan node sebelumnya ke node berikutnya
    } else {
        headRute = temp->next;  // Jika yang dihapus adalah node pertama
    }

    delete temp;  // Menghapus node yang telah dipilih

    cout << "Rute berhasil dihapus!" << endl;
}

// Fungsi untuk menghapus pemesanan pertama di antrian
void hapusAntrian() {
    if (!frontQueue) {
        cout << "Tidak ada pemesanan dalam antrian." << endl;
        return;
    }

    // Menghapus pemesanan pertama dalam antrian
    NodePemesananQueue* temp = frontQueue;
    frontQueue = frontQueue->next;


    if (!frontQueue) {
        rearQueue = nullptr;
    }

    delete temp;  
    cout << "Pemesanan pertama dalam antrian berhasil dihapus!" << endl;
}


public:
    // Konstruktor untuk menambahkan beberapa rute awal
    SistemTiketKereta() {
        headRute = nullptr;
        topPemesanan = nullptr;
        frontQueue = rearQueue = nullptr;

        //Data Awal
        headRute = new NodeRute{ {"Bandung", "Jakarta", "08:00", "10:30", 150000}, nullptr };
        headRute->next = new NodeRute{ {"Jakarta", "Surabaya", "09:00", "17:00", 300000}, nullptr };
        headRute->next->next = new NodeRute{ {"Yogyakarta", "Solo", "07:00", "08:30", 200000}, nullptr };
        headRute->next->next->next = new NodeRute{ {"Semarang", "Jakarta", "15:00", "18:00", 250000}, nullptr };
        headRute->next->next->next->next = new NodeRute{ {"Surabaya", "Bali", "13:00", "19:30", 500000}, nullptr };
        headRute->next->next->next->next->next = new NodeRute{ {"Bandung", "Yogyakarta", "06:00", "09:00", 100000}, nullptr };
    }

    // Menu utama untuk login
    void menu() {
        int pilihan;
        cout << "Selamat datang di Sistem Pemesanan Tiket Kereta!" << endl;
        cout << "1. Login Pengguna" << endl;
        cout << "2. Login Admin" << endl;
        cout << "3. Registrasi Pengguna" << endl; // Menambahkan opsi registrasi
        cout << "4. Keluar" << endl;
        cout << "Pilih opsi: ";
        while (true) {
            cout << "Pilih opsi: ";
            cin >> pilihan;

            
            if (cin.fail() || pilihan < 1 || pilihan > 4) {
                cout << "Input tidak valid! Silakan masukkan angka antara 1 hingga 4." << endl;
                cin.clear(); 
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Membuang input tidak valid dari buffer
            } else {
                break;
            }
        }


        if (pilihan == 1) {
        string username, password;
        int attempts = 0;

        while (attempts < 3) {
            cout << "Masukkan username: ";
            cin >> username;
            cout << "Masukkan password: ";
            cin >> password;

            if (loginPengguna(username, password)) {
                cout << "Login berhasil!" << endl;
                menuPengguna(username);
                return;
            } else {
                cout << "Username atau password salah!" << endl;
                attempts++;
                if (attempts >= 3) {
                    cout << "Anda telah mencoba login sebanyak 3 kali." << endl;
                    cout << "Silakan registrasi jika belum memiliki akun, atau kembali ke menu utama." << endl;
                    menu();
                    return; // Kembali ke menu utama
                }
            }
        }
    } else if (pilihan == 2) {
        string username, password;
        int attempts = 0;

        while (attempts < 3) {
            cout << "Masukkan username: ";
            cin >> username;
            cout << "Masukkan password: ";
            cin >> password;

            if (loginAdmin(username, password)) {
                cout << "Login berhasil!" << endl;
                menuAdmin();
                return;
            } else {
                cout << "Username atau password salah!" << endl;
                attempts++;
                if (attempts >= 3) {
                    cout << "Anda telah mencoba login sebagai admin sebanyak 3 kali." << endl;
                    cout << "Kembali ke menu utama." << endl;
                    menu();
                    return; // Kembali ke menu utama
                }
            }
        }
    } else if (pilihan == 3) {
        registrasi();
        menu();
    } else {
        cout << "Terima kasih!" << endl;
    }
}

    // Menu pengguna setelah login
    void menuPengguna(string username) {
        int pilihan;
        cout << "\nMenu Pengguna:\n";
        cout << "1. Lihat Rute" << endl;
        cout << "2. Pesan Tiket" << endl;
        cout << "3. Batalkan Pemesanan" << endl;
        cout << "4. Cari Rute" << endl;
        cout << "5. Logout" << endl;
        cout << "Pilih opsi: ";
        while (true) {
            cout << "Pilih opsi: ";
            cin >> pilihan;

            
            if (cin.fail() || pilihan < 1 || pilihan > 5) {
                cout << "Input tidak valid! Silakan masukkan angka antara 1 hingga 5." << endl;
                cin.clear(); 
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Membuang input tidak valid dari buffer
            } else {
                break;
            }
        }

        if (pilihan == 1) {
            lihatRute();
            menuPengguna(username);
        } else if (pilihan == 2) {
            belitiket(username);
            menuPengguna(username);
        } else if (pilihan == 3) {
            hapusAntrian();
            menuPengguna(username);
        } else if (pilihan == 4) {
            cariRute();
            menuPengguna(username);
        } else {
            menu();
        }
    }

    // Menu admin setelah login
    void menuAdmin() {
        int pilihan;
        cout << "\nMenu Admin:\n";
        cout << "1. Lihat Rute" << endl;
        cout << "2. Tambah Rute" << endl;
        cout << "3. Hapus Rute" << endl;
        cout << "4. Edit Rute" << endl;
        cout << "5. Lihat Pemesanan dari Pelanggan" << endl;  
        cout << "6. Menghapus Pemesanan" << endl;
        cout << "7. Sorting Berdasarkan Jam Keberangkatan" << endl;
        cout << "8. Sorting Berdasarkan Harga" << endl;
        cout << "9. Logout" << endl;
        cout << "Pilih opsi: ";
        while (true) {
            cout << "Pilih opsi: ";
            cin >> pilihan;

            
            if (cin.fail() || pilihan < 1 || pilihan > 9) {
                cout << "Input tidak valid! Silakan masukkan angka antara 1 hingga 9." << endl;
                cin.clear(); 
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Membuang input tidak valid dari buffer
            } else {
                break;
            }
        }

        if (pilihan == 1) {
            lihatRute();
            menuAdmin();
        } else if (pilihan == 2) {
            tambahRute();
            menuAdmin();
        } else if (pilihan == 3) {
            hapusrute(); 
            menuAdmin();
        } else if (pilihan == 4) {
            editRute();
            menuAdmin();
        } else if (pilihan == 5) {
            liatantrian();
            menuAdmin();
        } else if (pilihan == 6) {
            hapusAntrian();
            menuAdmin();
        } else if (pilihan == 7) {
            sortingJamKeberangkatan();
            menuAdmin();
        } else if (pilihan == 8) {
            shellSort();
            menuAdmin();
        } else {
            menu();
        }
    }
};

int main() {
    SistemTiketKereta sistem;
    sistem.menu();  // Menampilkan menu utama
    return 0;
}
